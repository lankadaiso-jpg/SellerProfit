import 'package:flutter_test/flutter_test.dart';
import 'package:sellerprofit/services/profit_calculator.dart';

void main() {
  group('ProfitCalculator', () {
    test('calculates line profit after Daraz settlement and unit costs', () {
      final profit = ProfitCalculator.orderLineProfit(
        lineSettlement: 1590,
        unitCost: 940,
        soldQuantity: 1,
      );
      expect(profit, 650);
    });

    test('reverses cost for saleable returned stock and includes return expense', () {
      final profit = ProfitCalculator.orderLineProfit(
        lineSettlement: 1590,
        unitCost: 940,
        soldQuantity: 1,
        restockedReturnedQuantity: 1,
        returnExpense: 50,
      );
      expect(profit, 1540);
    });

    test('allocates an order-level charge by product revenue share', () {
      final share = ProfitCalculator.allocateOrderAmount(
        orderAmount: -100,
        lineProductRevenue: 250,
        totalOrderProductRevenue: 500,
      );
      expect(share, -50);
    });

    test('does not allocate when an order has no product revenue', () {
      expect(ProfitCalculator.allocateOrderAmount(
        orderAmount: -100,
        lineProductRevenue: 0,
        totalOrderProductRevenue: 0,
      ), 0);
    });
  });
}
