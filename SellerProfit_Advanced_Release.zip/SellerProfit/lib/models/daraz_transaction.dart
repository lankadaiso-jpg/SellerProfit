class DarazTransaction {
  final String statementNumber;
  final String statementPeriod;
  final String transactionDate;
  final String feeName;
  final double amount;
  final double vatAmount;
  final double whtAmount;
  final String whtIncludedInAmount;
  final String releaseDate;
  final String comment;
  final String orderCreationDate;
  final String lazadaSku;
  final String shortCode;
  final String releaseStatus;
  final String orderNumber;
  final String orderLineId;
  final String sellerSku;
  final String productName;
  final String orderStatus;

  const DarazTransaction({
    required this.statementNumber,
    required this.statementPeriod,
    required this.transactionDate,
    required this.feeName,
    required this.amount,
    required this.vatAmount,
    required this.whtAmount,
    required this.whtIncludedInAmount,
    required this.releaseDate,
    required this.comment,
    required this.orderCreationDate,
    required this.lazadaSku,
    required this.shortCode,
    required this.releaseStatus,
    required this.orderNumber,
    required this.orderLineId,
    required this.sellerSku,
    required this.productName,
    required this.orderStatus,
  });

  Map<String, Object?> toMap() => {
    'statement_number': statementNumber,
    'statement_period': statementPeriod,
    'transaction_date': transactionDate,
    'fee_name': feeName,
    'amount': amount,
    'vat_amount': vatAmount,
    'wht_amount': whtAmount,
    'wht_included_in_amount': whtIncludedInAmount,
    'release_date': releaseDate,
    'comment': comment,
    'order_creation_date': orderCreationDate,
    'lazada_sku': lazadaSku,
    'short_code': shortCode,
    'release_status': releaseStatus,
    'order_number': orderNumber,
    'order_line_id': orderLineId,
    'seller_sku': sellerSku,
    'product_name': productName,
    'order_status': orderStatus,
  };
}
