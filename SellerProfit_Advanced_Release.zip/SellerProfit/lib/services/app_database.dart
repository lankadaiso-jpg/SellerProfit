import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models/daraz_transaction.dart';
import 'daraz_excel_parser.dart';
import 'profit_calculator.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'sellerprofit.db');
    _db = await openDatabase(path, version: 3, onCreate: _create, onUpgrade: _upgrade);
    return _db!;
  }

  Future<void> _create(Database d, int version) async {
    await d.execute('''CREATE TABLE stores (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE,
      marketplace TEXT NOT NULL DEFAULT 'Daraz Sri Lanka', created_at TEXT NOT NULL)''');
    await d.insert('stores', {'name':'My Daraz Store 1','created_at':DateTime.now().toIso8601String()});
    await d.execute('''CREATE TABLE statements (
      id INTEGER PRIMARY KEY AUTOINCREMENT, store_id INTEGER NOT NULL DEFAULT 1,
      statement_number TEXT NOT NULL, statement_period TEXT, imported_at TEXT NOT NULL,
      transaction_count INTEGER NOT NULL, net_settlement REAL NOT NULL,
      UNIQUE(store_id, statement_number))''');
    await d.execute('''CREATE TABLE transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT, statement_number TEXT NOT NULL,
      statement_period TEXT, transaction_date TEXT, fee_name TEXT NOT NULL,
      amount REAL NOT NULL, vat_amount REAL NOT NULL, wht_amount REAL NOT NULL DEFAULT 0,
      wht_included_in_amount TEXT, release_date TEXT, comment TEXT, order_creation_date TEXT,
      lazada_sku TEXT, short_code TEXT, release_status TEXT, order_number TEXT,
      order_line_id TEXT, seller_sku TEXT, product_name TEXT, order_status TEXT,
      store_id INTEGER NOT NULL DEFAULT 1)''');
    await d.execute('CREATE INDEX idx_tx_statement ON transactions(store_id, statement_number)');
    await d.execute('CREATE INDEX idx_tx_sku ON transactions(store_id, seller_sku)');
    await d.execute('CREATE INDEX idx_tx_order ON transactions(store_id, order_number, order_line_id)');
    await d.execute('''CREATE TABLE products (
      id INTEGER PRIMARY KEY AUTOINCREMENT, seller_sku TEXT NOT NULL,
      product_name TEXT NOT NULL, purchase_cost REAL NOT NULL DEFAULT 0,
      packaging_cost REAL NOT NULL DEFAULT 0, other_unit_cost REAL NOT NULL DEFAULT 0,
      confirmed INTEGER NOT NULL DEFAULT 0, store_id INTEGER NOT NULL DEFAULT 1,
      UNIQUE(store_id, seller_sku))''');
    await d.execute('''CREATE TABLE expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT, expense_date TEXT NOT NULL,
      category TEXT NOT NULL, description TEXT, amount REAL NOT NULL,
      store_id INTEGER NOT NULL DEFAULT 1)''');
    await _createPhaseOnePlus(d);
  }

  Future<void> _upgrade(Database d, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await d.execute('''CREATE TABLE stores (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, marketplace TEXT NOT NULL DEFAULT 'Daraz Sri Lanka', created_at TEXT NOT NULL)''');
      await d.insert('stores', {'name':'My Daraz Store 1','created_at':DateTime.now().toIso8601String()});
      await d.execute('ALTER TABLE statements RENAME TO statements_v1');
      await d.execute('''CREATE TABLE statements (
        id INTEGER PRIMARY KEY AUTOINCREMENT, store_id INTEGER NOT NULL DEFAULT 1,
        statement_number TEXT NOT NULL, statement_period TEXT, imported_at TEXT NOT NULL,
        transaction_count INTEGER NOT NULL, net_settlement REAL NOT NULL,
        UNIQUE(store_id, statement_number))''');
      await d.execute('''INSERT INTO statements(id,store_id,statement_number,statement_period,imported_at,transaction_count,net_settlement)
        SELECT id,1,statement_number,statement_period,imported_at,transaction_count,net_settlement FROM statements_v1''');
      await d.execute('DROP TABLE statements_v1');
      await d.execute('ALTER TABLE transactions ADD COLUMN store_id INTEGER NOT NULL DEFAULT 1');
      await d.execute('ALTER TABLE products RENAME TO products_v1');
      await d.execute('''CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT, seller_sku TEXT NOT NULL,
        product_name TEXT NOT NULL, purchase_cost REAL NOT NULL DEFAULT 0,
        packaging_cost REAL NOT NULL DEFAULT 0, other_unit_cost REAL NOT NULL DEFAULT 0,
        confirmed INTEGER NOT NULL DEFAULT 0, store_id INTEGER NOT NULL DEFAULT 1,
        UNIQUE(store_id, seller_sku))''');
      await d.execute('''INSERT INTO products(id,seller_sku,product_name,purchase_cost,packaging_cost,other_unit_cost,confirmed,store_id)
        SELECT id,seller_sku,product_name,purchase_cost,packaging_cost,other_unit_cost,confirmed,1 FROM products_v1''');
      await d.execute('DROP TABLE products_v1');
      await d.execute('ALTER TABLE expenses ADD COLUMN store_id INTEGER NOT NULL DEFAULT 1');
      await d.execute('CREATE INDEX IF NOT EXISTS idx_tx_order ON transactions(store_id, order_number, order_line_id)');
      await _createPhaseOnePlus(d);
    }
    if (oldVersion < 3) {
      await d.execute('ALTER TABLE transactions ADD COLUMN wht_amount REAL NOT NULL DEFAULT 0');
      await d.execute('ALTER TABLE transactions ADD COLUMN wht_included_in_amount TEXT');
      await d.execute('ALTER TABLE transactions ADD COLUMN release_date TEXT');
      await d.execute('ALTER TABLE transactions ADD COLUMN comment TEXT');
      await d.execute('ALTER TABLE transactions ADD COLUMN order_creation_date TEXT');
      await d.execute('ALTER TABLE transactions ADD COLUMN lazada_sku TEXT');
      await d.execute('ALTER TABLE transactions ADD COLUMN short_code TEXT');
    }
  }

  Future<void> _createPhaseOnePlus(Database d) async {
    await d.execute('''CREATE TABLE IF NOT EXISTS order_line_quantities (
      id INTEGER PRIMARY KEY AUTOINCREMENT, store_id INTEGER NOT NULL,
      order_number TEXT NOT NULL, order_line_id TEXT NOT NULL, seller_sku TEXT NOT NULL,
      quantity REAL NOT NULL, confirmed INTEGER NOT NULL DEFAULT 0,
      UNIQUE(store_id, order_line_id, seller_sku))''');
    await d.execute('''CREATE TABLE IF NOT EXISTS returns (
      id INTEGER PRIMARY KEY AUTOINCREMENT, store_id INTEGER NOT NULL,
      order_number TEXT NOT NULL, order_line_id TEXT NOT NULL, seller_sku TEXT NOT NULL,
      returned_quantity REAL NOT NULL DEFAULT 0, restockable INTEGER NOT NULL DEFAULT 0,
      return_expense REAL NOT NULL DEFAULT 0, notes TEXT, return_date TEXT NOT NULL)''');
    await d.execute('''CREATE TABLE IF NOT EXISTS import_audit (
      id INTEGER PRIMARY KEY AUTOINCREMENT, store_id INTEGER NOT NULL,
      statement_number TEXT NOT NULL, source_file TEXT, imported_at TEXT NOT NULL,
      imported_rows INTEGER NOT NULL, UNIQUE(store_id, statement_number))''');
  }

  Future<List<Map<String,Object?>>> stores() async => (await db).query('stores', orderBy:'id');
  Future<int> addStore(String name) async => (await db).insert('stores', {'name':name.trim(),'created_at':DateTime.now().toIso8601String()});

  Future<bool> importStatement(ParsedStatement statement, {int storeId = 1, String? sourceFile}) async {
    final database = await db;
    return database.transaction((txn) async {
      final existing = await txn.query('statements', where:'store_id = ? AND statement_number = ?', whereArgs:[storeId, statement.statementNumber]);
      if (existing.isNotEmpty) return false;
      await txn.insert('statements', {'store_id':storeId,'statement_number':statement.statementNumber,'statement_period':statement.statementPeriod,'imported_at':DateTime.now().toIso8601String(),'transaction_count':statement.transactions.length,'net_settlement':statement.netSettlement});
      final batch = txn.batch();
      for (final row in statement.transactions) { batch.insert('transactions', {...row.toMap(),'store_id':storeId}); }
      await batch.commit(noResult:true);
      final skus = <String,String>{};
      for (final row in statement.transactions) { if (row.sellerSku.isNotEmpty) skus[row.sellerSku] = row.productName; }
      for (final entry in skus.entries) {
        await txn.insert('products', {'store_id':storeId,'seller_sku':entry.key,'product_name':entry.value}, conflictAlgorithm:ConflictAlgorithm.ignore);
      }
      await txn.insert('import_audit', {'store_id':storeId,'statement_number':statement.statementNumber,'source_file':sourceFile,'imported_at':DateTime.now().toIso8601String(),'imported_rows':statement.transactions.length});
      return true;
    });
  }

  Future<Map<String,Object?>> summary({int storeId=1}) async {
    final d=await db;
    final tx=await d.rawQuery('''SELECT
      COALESCE(SUM(CASE WHEN fee_name='Product Price Paid by Buyer' THEN amount ELSE 0 END),0) product_sales,
      COALESCE(SUM(amount),0) settlement, COALESCE(SUM(vat_amount),0) vat_total, COALESCE(SUM(wht_amount),0) wht_total, COUNT(*) transaction_count
      FROM transactions WHERE store_id=?''',[storeId]);
    final st=await d.rawQuery('SELECT COUNT(*) count FROM statements WHERE store_id=?',[storeId]);
    final costs=await d.rawQuery('''SELECT COALESCE(SUM(e.amount),0) expenses FROM expenses e WHERE e.store_id=?''',[storeId]);
    final unallocated=await d.rawQuery('''SELECT COALESCE(SUM(t.amount),0) amount FROM transactions t WHERE t.store_id=? AND COALESCE(t.order_line_id,'')='' AND (COALESCE(t.order_number,'')='' OR NOT EXISTS (SELECT 1 FROM transactions x WHERE x.store_id=t.store_id AND x.order_number=t.order_number AND x.fee_name='Product Price Paid by Buyer' AND x.amount>0))''',[storeId]);
    return {...tx.first,'statement_count':st.first['count'],'expenses':costs.first['expenses'],'unallocated_amount':unallocated.first['amount']};
  }

  Future<List<Map<String,Object?>>> feeBreakdown({int storeId=1}) async => (await db).rawQuery('SELECT fee_name, SUM(amount) total FROM transactions WHERE store_id=? GROUP BY fee_name ORDER BY total ASC',[storeId]);
  Future<List<Map<String,Object?>>> products({int storeId=1}) async => (await db).query('products',where:'store_id=?',whereArgs:[storeId],orderBy:'product_name COLLATE NOCASE');
  Future<void> saveProductCost({required int storeId,required String sku,required String name,required double purchase,required double packaging,required double other}) async => (await db).update('products',{'product_name':name,'purchase_cost':purchase,'packaging_cost':packaging,'other_unit_cost':other,'confirmed':1},where:'store_id=? AND seller_sku=?',whereArgs:[storeId,sku]);
  Future<List<Map<String,Object?>>> statements({int storeId=1}) async => (await db).query('statements',where:'store_id=?',whereArgs:[storeId],orderBy:'imported_at DESC');

  Future<List<Map<String,Object?>>> orderLines({int storeId=1}) async {
    final d=await db;
    final raw=await d.rawQuery('''SELECT t.order_number,t.order_line_id,t.seller_sku,
      MAX(t.product_name) product_name,MAX(t.order_status) order_status,MAX(t.order_creation_date) order_creation_date,
      SUM(CASE WHEN t.fee_name='Product Price Paid by Buyer' THEN t.amount ELSE 0 END) product_revenue,
      SUM(CASE WHEN t.order_line_id IS NOT NULL AND t.order_line_id<>'' THEN t.amount ELSE 0 END) line_settlement,
      COUNT(DISTINCT t.statement_number) statement_count
      FROM transactions t WHERE t.store_id=? AND COALESCE(t.order_line_id,'')<>''
      GROUP BY t.order_number,t.order_line_id,t.seller_sku ORDER BY MAX(t.transaction_date) DESC''',[storeId]);
    final costs=await d.query('products',where:'store_id=?',whereArgs:[storeId]);
    final costMap={for(final p in costs) '${p['seller_sku']}':p};
    final quantities=await d.query('order_line_quantities',where:'store_id=?',whereArgs:[storeId]);
    final qtyMap={for(final q in quantities) '${q['order_line_id']}|${q['seller_sku']}':q};
    final returnRows=await d.query('returns',where:'store_id=?',whereArgs:[storeId]);
    final retMap=<String,Map<String,double>>{};
    for(final r in returnRows){final k='${r['order_line_id']}|${r['seller_sku']}'; final old=retMap[k]??{'qty':0.0,'expense':0.0,'restock':0.0}; old['qty']=old['qty']!+(r['returned_quantity'] as num).toDouble(); old['expense']=old['expense']!+(r['return_expense'] as num).toDouble(); if((r['restockable'] as num)==1) old['restock']=old['restock']!+(r['returned_quantity'] as num).toDouble(); retMap[k]=old;}
    // Allocate order-level transaction rows (no line ID) proportionally to product revenue.
    final unlinked=await d.rawQuery('''SELECT order_number,SUM(amount) amount FROM transactions WHERE store_id=? AND COALESCE(order_line_id,'')='' AND COALESCE(order_number,'')<>'' GROUP BY order_number''',[storeId]);
    final revByOrder=<String,double>{}; for(final r in raw){final k='${r['order_number']}'; revByOrder[k]=(revByOrder[k]??0)+((r['product_revenue'] as num?)?.toDouble()??0);}
    final allocation=<String,double>{};
    for(final u in unlinked){final order='${u['order_number']}';final total=revByOrder[order]??0;if(total<=0)continue;for(final r in raw){if('${r['order_number']}'==order){final key='${r['order_line_id']}|${r['seller_sku']}';final share=ProfitCalculator.allocateOrderAmount(orderAmount:(u['amount'] as num).toDouble(),lineProductRevenue:(r['product_revenue'] as num?)?.toDouble()??0,totalOrderProductRevenue:total);allocation[key]=(allocation[key]??0)+share;}}}
    return raw.map((r){final key='${r['order_line_id']}|${r['seller_sku']}';final p=costMap['${r['seller_sku']}'];final q=qtyMap[key];final ret=retMap[key]??{'qty':0.0,'expense':0.0,'restock':0.0};final qty=(q?['quantity'] as num?)?.toDouble()??0;final confirmed=(q?['confirmed'] as num?)==1;final unit=((p?['purchase_cost'] as num?)?.toDouble()??0)+((p?['packaging_cost'] as num?)?.toDouble()??0)+((p?['other_unit_cost'] as num?)?.toDouble()??0);final netLine=((r['line_settlement'] as num?)?.toDouble()??0)+(allocation[key]??0);final actual=ProfitCalculator.orderLineProfit(lineSettlement:netLine,unitCost:unit,soldQuantity:qty,restockedReturnedQuantity:ret['restock']??0,returnExpense:ret['expense']??0);final costConfirmed=(p?['confirmed'] as num?)==1;return {...r,'quantity':qty,'quantity_confirmed':confirmed?1:0,'cost_confirmed':costConfirmed?1:0,'allocated_order_fees':allocation[key]??0,'returns_quantity':ret['qty']??0,'actual_profit':actual,'profit_ready':confirmed&&costConfirmed?1:0,'unallocated_fee_warning':false};}).toList();
  }

  Future<void> saveOrderQuantity({required int storeId,required String orderNumber,required String orderLineId,required String sku,required double quantity}) async => (await db).insert('order_line_quantities',{'store_id':storeId,'order_number':orderNumber,'order_line_id':orderLineId,'seller_sku':sku,'quantity':quantity,'confirmed':1},conflictAlgorithm:ConflictAlgorithm.replace);
  Future<void> addReturn({required int storeId,required String orderNumber,required String orderLineId,required String sku,required double quantity,required bool restockable,required double expense,required String notes}) async {
    final d=await db;
    await d.transaction((txn) async {
      final q=await txn.query('order_line_quantities',where:'store_id=? AND order_line_id=? AND seller_sku=?',whereArgs:[storeId,orderLineId,sku],limit:1);
      if(q.isEmpty || (q.first['confirmed'] as num)!=1) throw StateError('Confirm the sold quantity before recording a return.');
      final existing=await txn.rawQuery('SELECT COALESCE(SUM(returned_quantity),0) total FROM returns WHERE store_id=? AND order_line_id=? AND seller_sku=?',[storeId,orderLineId,sku]);
      final returned=(existing.first['total'] as num).toDouble();
      final sold=(q.first['quantity'] as num).toDouble();
      if(quantity<=0 || returned+quantity>sold) throw StateError('Total returned quantity cannot exceed the confirmed sold quantity.');
      await txn.insert('returns',{'store_id':storeId,'order_number':orderNumber,'order_line_id':orderLineId,'seller_sku':sku,'returned_quantity':quantity,'restockable':restockable?1:0,'return_expense':expense,'notes':notes,'return_date':DateTime.now().toIso8601String()});
    });
  }
  Future<List<Map<String,Object?>>> expenses({int storeId=1}) async => (await db).query('expenses',where:'store_id=?',whereArgs:[storeId],orderBy:'expense_date DESC');
  Future<void> addExpense({required int storeId,required String date,required String category,required String description,required double amount}) async => (await db).insert('expenses',{'store_id':storeId,'expense_date':date,'category':category,'description':description,'amount':amount});

  Future<List<Map<String,Object?>>> monthlyReports({int storeId=1}) async {
    final d=await db;
    final rows=await d.query('transactions',columns:['transaction_date','fee_name','amount'],where:'store_id=?',whereArgs:[storeId]);
    final expenseRows=await d.query('expenses',columns:['expense_date','amount'],where:'store_id=?',whereArgs:[storeId]);
    final lines=await orderLines(storeId:storeId);
    final months=<String,Map<String,Object?>>{};
    Map<String,Object?> month(String key)=>months.putIfAbsent(key,()=>{'month':key,'settlement':0.0,'product_sales':0.0,'transaction_count':0,'expenses':0.0,'confirmed_order_profit':0.0,'monthly_profit':0.0,'confirmed_lines':0,'pending_lines':0});
    DateTime? parseDate(Object? value){final raw='${value??''}';try{return DateFormat('d MMM yyyy','en_US').parseStrict(raw);}catch(_){return DateTime.tryParse(raw);}}
    for(final r in rows){final date=parseDate(r['transaction_date']);if(date==null)continue;final m=month(DateFormat('yyyy-MM').format(date));final amount=(r['amount'] as num).toDouble();m['settlement']=(m['settlement'] as double)+amount;if(r['fee_name']=='Product Price Paid by Buyer')m['product_sales']=(m['product_sales'] as double)+amount;m['transaction_count']=(m['transaction_count'] as int)+1;}
    for(final r in expenseRows){final date=DateTime.tryParse('${r['expense_date']??''}');if(date==null)continue;final m=month(DateFormat('yyyy-MM').format(date));m['expenses']=(m['expenses'] as double)+(r['amount'] as num).toDouble();}
    for(final line in lines){final date=parseDate(line['order_creation_date']);if(date==null)continue;final m=month(DateFormat('yyyy-MM').format(date));if((line['profit_ready'] as num)==1){m['confirmed_order_profit']=(m['confirmed_order_profit'] as double)+(line['actual_profit'] as num).toDouble();m['confirmed_lines']=(m['confirmed_lines'] as int)+1;}else{m['pending_lines']=(m['pending_lines'] as int)+1;}}
    for(final m in months.values){m['monthly_profit']=(m['confirmed_order_profit'] as double)-(m['expenses'] as double);}
    final result=months.values.toList();result.sort((a,b)=>'${b['month']}'.compareTo('${a['month']}'));return result;
  }

  Future<Map<String,Object?>> backupJson() async {
    final d=await db; final result=<String,Object?>{};
    for(final table in ['stores','statements','transactions','products','expenses','order_line_quantities','returns','import_audit']){result[table]=await d.query(table);}
    result['backup_version']=2;result['created_at']=DateTime.now().toIso8601String();return result;
  }
  Future<void> restoreJson(String source) async {
    final decoded=jsonDecode(source) as Map<String,dynamic>;final d=await db;
    await d.transaction((txn) async {
      for(final table in ['stores','statements','transactions','products','expenses','order_line_quantities','returns','import_audit']){
        final rows=(decoded[table] as List?)??[]; await txn.delete(table);
        for(final item in rows){final row=Map<String,Object?>.from(item as Map);row.remove('id');await txn.insert(table,row,conflictAlgorithm:ConflictAlgorithm.replace);}
      }
    });
  }
}
