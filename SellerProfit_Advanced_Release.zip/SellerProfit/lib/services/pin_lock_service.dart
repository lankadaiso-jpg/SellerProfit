import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class PinLockService {
  PinLockService._();
  static final PinLockService instance = PinLockService._();
  static const _storage = FlutterSecureStorage();
  static const _saltKey = 'sellerprofit_pin_salt_v1';
  static const _hashKey = 'sellerprofit_pin_hash_v1';

  Future<bool> isPinConfigured() async => (await _storage.read(key: _hashKey)) != null;

  String _hash(String pin, String salt) => sha256.convert(utf8.encode('$salt:$pin')).toString();

  Future<void> setPin(String pin) async {
    final random = Random.secure();
    final salt = List<int>.generate(16, (_) => random.nextInt(256)).map((v) => v.toRadixString(16).padLeft(2, '0')).join();
    await _storage.write(key: _saltKey, value: salt);
    await _storage.write(key: _hashKey, value: _hash(pin, salt));
  }

  Future<bool> verifyPin(String pin) async {
    final salt = await _storage.read(key: _saltKey);
    final savedHash = await _storage.read(key: _hashKey);
    if (salt == null || savedHash == null) return false;
    return _hash(pin, salt) == savedHash;
  }
}
