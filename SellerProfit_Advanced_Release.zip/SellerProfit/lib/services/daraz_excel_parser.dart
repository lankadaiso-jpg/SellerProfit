import 'dart:typed_data';
import 'package:excel/excel.dart';
import '../models/daraz_transaction.dart';

class ParsedStatement {
  final String statementNumber;
  final String statementPeriod;
  final List<DarazTransaction> transactions;
  const ParsedStatement({required this.statementNumber, required this.statementPeriod, required this.transactions});
  double get netSettlement => transactions.fold(0, (sum, row) => sum + row.amount);
}

class DarazExcelParser {
  static String _str(Data? cell) => (cell?.value?.toString() ?? '').trim();
  static double _num(Data? cell) {
    final raw = _str(cell).replaceAll(',', '').replaceAll('Rs.', '').trim();
    return double.tryParse(raw) ?? 0;
  }

  ParsedStatement parse(Uint8List bytes) {
    final workbook = Excel.decodeBytes(bytes);
    if (workbook.tables.isEmpty) throw const FormatException('The workbook has no readable sheets.');
    for (final table in workbook.tables.values) {
      if (table == null || table.rows.isEmpty) continue;
      var headerIndex = -1;
      final headers = <String, int>{};
      for (var i = 0; i < table.rows.length; i++) {
        final row = table.rows[i];
        final found = <String, int>{};
        for (var c = 0; c < row.length; c++) {
          final label = _str(row[c]).toLowerCase();
          if (label.isNotEmpty) found[label] = c;
        }
        if (found.containsKey('fee name') && found.containsKey('amount(include tax)')) {
          headerIndex = i;
          headers.addAll(found);
          break;
        }
      }
      if (headerIndex < 0) continue;
      int col(String name) => headers[name.toLowerCase()] ?? -1;
      Data? cell(List<Data?> row, String name) {
        final index = col(name);
        return index >= 0 && index < row.length ? row[index] : null;
      }
      final output = <DarazTransaction>[];
      for (var i = headerIndex + 1; i < table.rows.length; i++) {
        final row = table.rows[i];
        final fee = _str(cell(row, 'Fee Name'));
        if (fee.isEmpty) continue;
        output.add(DarazTransaction(
          statementNumber: _str(cell(row, 'Statement Number')),
          statementPeriod: _str(cell(row, 'Statement Period')),
          transactionDate: _str(cell(row, 'Transaction Date')),
          feeName: fee,
          amount: _num(cell(row, 'Amount(Include Tax)')),
          vatAmount: _num(cell(row, 'VAT Amount')),
          whtAmount: _num(cell(row, 'WHT Amount')),
          whtIncludedInAmount: _str(cell(row, 'WHT included in Amount')),
          releaseDate: _str(cell(row, 'Release Date')),
          comment: _str(cell(row, 'Comment')),
          orderCreationDate: _str(cell(row, 'Order Creation Date')),
          lazadaSku: _str(cell(row, 'Lazada SKU')),
          shortCode: _str(cell(row, 'Short Code')),
          releaseStatus: _str(cell(row, 'Release Status')),
          orderNumber: _str(cell(row, 'Order Number')),
          orderLineId: _str(cell(row, 'Order Line ID')),
          sellerSku: _str(cell(row, 'Seller SKU')),
          productName: _str(cell(row, 'Product Name')),
          orderStatus: _str(cell(row, 'Order Status')),
        ));
      }
      if (output.isEmpty) throw const FormatException('No transaction rows were found under the Daraz headers.');
      final statementNo = output.first.statementNumber;
      if (statementNo.isEmpty) throw const FormatException('Statement Number is missing.');
      return ParsedStatement(statementNumber: statementNo, statementPeriod: output.first.statementPeriod, transactions: output);
    }
    throw const FormatException('Unsupported Excel format. Expected Daraz columns: Fee Name and Amount(Include Tax).');
  }
}
