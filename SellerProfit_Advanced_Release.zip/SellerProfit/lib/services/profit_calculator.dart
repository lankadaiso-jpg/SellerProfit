class ProfitCalculator {
  const ProfitCalculator._();

  /// Calculates profit from the Daraz settlement assigned to one order line.
  /// [restockedReturnedQuantity] reverses COGS only for units physically returned
  /// to saleable stock. Refunds/credits from Daraz must already be in settlement.
  static double orderLineProfit({
    required double lineSettlement,
    required double unitCost,
    required double soldQuantity,
    double restockedReturnedQuantity = 0,
    double returnExpense = 0,
  }) {
    final sold = soldQuantity < 0 ? 0.0 : soldQuantity;
    final returnedToStock = restockedReturnedQuantity < 0 ? 0.0 : restockedReturnedQuantity;
    final saleableUnits = (sold - returnedToStock).clamp(0.0, sold);
    final cogs = saleableUnits * unitCost;
    return lineSettlement - cogs - returnExpense;
  }

  /// Allocates order-level charges by each line's share of positive product revenue.
  static double allocateOrderAmount({
    required double orderAmount,
    required double lineProductRevenue,
    required double totalOrderProductRevenue,
  }) {
    if (totalOrderProductRevenue <= 0) return 0;
    return orderAmount * (lineProductRevenue / totalOrderProductRevenue);
  }
}
