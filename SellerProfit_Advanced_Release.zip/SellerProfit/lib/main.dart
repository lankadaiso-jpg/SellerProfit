import 'dart:convert';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'services/app_database.dart';
import 'services/daraz_excel_parser.dart';
import 'screens/pin_gate.dart';

void main() => runApp(const SellerProfitApp());

class SellerProfitApp extends StatelessWidget {
  const SellerProfitApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title:'SellerProfit',debugShowCheckedModeBanner:false,
    theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF2457C5)),useMaterial3:true,scaffoldBackgroundColor:const Color(0xFFF5F7FB)),
    home:PinGate(builder:(context,lockNow,changePin)=>HomeScreen(onLock:lockNow,onChangePin:changePin)),
  );
}

String money(Object? value)=>NumberFormat.currency(locale:'en_LK',symbol:'Rs. ',decimalDigits:2).format((value as num?)?.toDouble()??0);

class HomeScreen extends StatefulWidget {
  final VoidCallback onLock; final Future<void> Function() onChangePin;
  const HomeScreen({super.key,required this.onLock,required this.onChangePin});
  @override State<HomeScreen> createState()=>_HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  int _tab=0,_storeId=1; bool _busy=false; String? _message; List<Map<String,Object?>> _stores=[]; Map<String,Object?> _summary={}; List<Map<String,Object?>> _products=[],_statements=[],_orders=[],_expenses=[],_fees=[];
  @override void initState(){super.initState();_refresh();}
  Future<void> _refresh() async {
    final db=AppDatabase.instance;final stores=await db.stores();if(stores.isNotEmpty&&!stores.any((s)=>(s['id'] as num).toInt()==_storeId))_storeId=(stores.first['id'] as num).toInt();
    final values=await Future.wait([db.summary(storeId:_storeId),db.products(storeId:_storeId),db.statements(storeId:_storeId),db.orderLines(storeId:_storeId),db.expenses(storeId:_storeId),db.feeBreakdown(storeId:_storeId)]);
    if(!mounted)return;setState((){_stores=stores;_summary=values[0] as Map<String,Object?>;_products=values[1] as List<Map<String,Object?>>;_statements=values[2] as List<Map<String,Object?>>;_orders=values[3] as List<Map<String,Object?>>;_expenses=values[4] as List<Map<String,Object?>>;_fees=values[5] as List<Map<String,Object?>>;});
  }
  Future<void> _importExcel() async {
    setState(()=>_busy=true);try{final result=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['xlsx'],withData:true);if(result==null)return;final bytes=result.files.single.bytes;if(bytes==null)throw Exception('Could not read the selected Excel file.');final parsed=DarazExcelParser().parse(bytes);final inserted=await AppDatabase.instance.importStatement(parsed,storeId:_storeId,sourceFile:result.files.single.name);_message=inserted?'Imported ${parsed.transactions.length} rows. Statement settlement: ${money(parsed.netSettlement)}':'This statement is already imported for this store.';await _refresh();}catch(e){_message='Import failed: $e';}finally{if(mounted)setState(()=>_busy=false);}
  }
  Future<void> _backup() async {try{final data=await AppDatabase.instance.backupJson();final bytes=Uint8List.fromList(utf8.encode(const JsonEncoder.withIndent('  ').convert(data)));final stamp=DateFormat('yyyyMMdd_HHmm').format(DateTime.now());final path=await FilePicker.platform.saveFile(fileName:'sellerprofit_backup_$stamp.json',bytes:bytes);if(path!=null&&mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Backup file saved. Keep it somewhere safe.')));}catch(e){_toast('Backup failed: $e');}}
  Future<void> _restore() async {try{final f=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['json'],withData:true);if(f==null)return;final bytes=f.files.single.bytes;if(bytes==null)throw Exception('Cannot read backup file.');final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Restore backup?'),content:const Text('This replaces all current SellerProfit records with the selected backup. Export a backup of current data first.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Restore'))]));if(ok==true){await AppDatabase.instance.restoreJson(utf8.decode(bytes));await _refresh();_toast('Backup restored.');}}catch(e){_toast('Restore failed: $e');}}
  void _toast(String s){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}
  Future<void> _addStore() async {final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Add Daraz store'),content:TextField(controller:c,decoration:const InputDecoration(labelText:'Store name',hintText:'e.g. Toyland')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,c.text.trim().isNotEmpty),child:const Text('Add'))]));if(ok==true){await AppDatabase.instance.addStore(c.text);final s=await AppDatabase.instance.stores();setState(()=>_storeId=(s.last['id'] as num).toInt());await _refresh();}c.dispose();}
  @override Widget build(BuildContext context){final pages=[_dashboard(),ProductScreen(products:_products,storeId:_storeId,onSaved:_refresh),OrderScreen(rows:_orders,storeId:_storeId,onChanged:_refresh),ExpenseScreen(rows:_expenses,storeId:_storeId,onChanged:_refresh),ReportScreen(fees:_fees,summary:_summary,storeId:_storeId),StatementScreen(statements:_statements)];
    return Scaffold(appBar:AppBar(title:const Text('SellerProfit',style:TextStyle(fontWeight:FontWeight.w800)),actions:[if(_stores.isNotEmpty)PopupMenuButton<int>(tooltip:'Select store',icon:const Icon(Icons.store),onSelected:(v)async{if(v==-1){await _addStore();}else{setState(()=>_storeId=v);await _refresh();}},itemBuilder:(c)=>[..._stores.map((s)=>PopupMenuItem(value:(s['id'] as num).toInt(),child:Text('${s['name']}'))),const PopupMenuDivider(),const PopupMenuItem(value:-1,child:Text('+ Add store'))],onCanceled:(){},),IconButton(onPressed:_busy?null:_importExcel,icon:const Icon(Icons.upload_file),tooltip:'Import Daraz Excel'),PopupMenuButton<String>(tooltip:'Settings and data',onSelected:(v){if(v=='lock')widget.onLock();if(v=='pin')widget.onChangePin();if(v=='backup')_backup();if(v=='restore')_restore();if(v=='store')_addStore();},itemBuilder:(c)=>const [PopupMenuItem(value:'store',child:Text('Add store')),PopupMenuItem(value:'pin',child:Text('Change PIN')),PopupMenuItem(value:'lock',child:Text('Lock now')),PopupMenuDivider(),PopupMenuItem(value:'backup',child:Text('Backup data')),PopupMenuItem(value:'restore',child:Text('Restore backup'))])]),
      body:SafeArea(child:pages[_tab]),floatingActionButton:_tab==0?FloatingActionButton.extended(onPressed:_busy?null:_importExcel,icon:_busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.upload_file),label:Text(_busy?'Importing...':'Upload statement')):null,
      bottomNavigationBar:NavigationBar(selectedIndex:_tab,onDestinationSelected:(v)=>setState(()=>_tab=v),destinations:const [NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'Home'),NavigationDestination(icon:Icon(Icons.inventory_2_outlined),label:'Products'),NavigationDestination(icon:Icon(Icons.receipt_long_outlined),label:'Orders'),NavigationDestination(icon:Icon(Icons.payments_outlined),label:'Expenses'),NavigationDestination(icon:Icon(Icons.analytics_outlined),label:'Reports'),NavigationDestination(icon:Icon(Icons.description_outlined),label:'Statements')]),);
  }
  Widget _dashboard() {
    final sales = (_summary['product_sales'] as num?)?.toDouble() ?? 0;
    final settlement = (_summary['settlement'] as num?)?.toDouble() ?? 0;
    final expense = (_summary['expenses'] as num?)?.toDouble() ?? 0;
    final ready = _orders.where((o) => (o['profit_ready'] as num) == 1).toList();
    final profit = ready.fold<double>(0, (sum, o) => sum + ((o['actual_profit'] as num?)?.toDouble() ?? 0)) - expense;
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF173B83), Color(0xFF3268D5)]),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('DARAZ BUSINESS OVERVIEW', style: TextStyle(color: Colors.white70, letterSpacing: 1.1, fontSize: 11)),
              const SizedBox(height: 10),
              Text(money(settlement), style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
              const Text('Net statement settlement', style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 14),
              Row(children: [_hero('Product sales', money(sales)), _hero('Statements', '${_summary['statement_count'] ?? 0}')]),
            ]),
          ),
          if (_message != null)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Card(child: ListTile(
                title: Text(_message!),
                trailing: IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() => _message = null)),
              )),
            ),
          const SizedBox(height: 14),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            childAspectRatio: 1.55,
            crossAxisSpacing: 9,
            mainAxisSpacing: 9,
            children: [
              _metric('Sales', money(sales), Icons.shopping_bag),
              _metric('Settlement', money(settlement), Icons.account_balance_wallet),
              _metric('Confirmed order lines', '${ready.length}', Icons.verified),
              _metric('Actual profit*', money(profit), Icons.trending_up),
              _metric('Operating expenses', money(expense), Icons.payments),
            ],
          ),
          if (((_summary['unallocated_amount'] as num?)?.toDouble() ?? 0).abs() > 0.005) Card(color: Colors.orange.shade50, child: ListTile(leading: const Icon(Icons.warning_amber), title: const Text('Unallocated Daraz adjustments'), subtitle: Text('${money(_summary['unallocated_amount'])} is not included in order-line profit. Review this in Reports.'))),
          Card(child: ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('Profit readiness'),
            subtitle: Text('${_orders.length - ready.length} order lines need confirmed quantity or product costs. *Shows confirmed-line profit less recorded expenses; pending lines and unallocated adjustments are excluded.'),
          )),
          Card(child: ListTile(
            leading: const Icon(Icons.lock_outline),
            title: const Text('Security and backup'),
            subtitle: const Text('PIN protected · Local database · Exportable backup'),
            onTap: _backup,
          )),
        ],
      ),
    );
  }
  Widget _hero(String l,String v)=>Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(v,style:const TextStyle(color:Colors.white,fontWeight:FontWeight.bold)),Text(l,style:const TextStyle(color:Colors.white70,fontSize:11))]));
  Widget _metric(String l,String v,IconData i)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Icon(i,color:Theme.of(context).colorScheme.primary),Text(v,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:15)),Text(l,style:const TextStyle(color:Colors.black54,fontSize:12))])));
}

class ProductScreen extends StatelessWidget {final List<Map<String,Object?>> products;final int storeId;final Future<void> Function() onSaved;const ProductScreen({super.key,required this.products,required this.storeId,required this.onSaved});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Product costs',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const Text('Enter verified supplier costs. Costs are stored separately for each Daraz store.'),const SizedBox(height:10),if(products.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('Upload a Daraz statement to discover products.'))),...products.map((p)=>Card(child:ListTile(title:Text('${p['product_name']}',maxLines:2,overflow:TextOverflow.ellipsis),subtitle:Text('SKU: ${p['seller_sku']}\nPurchase ${money(p['purchase_cost'])} · Packaging ${money(p['packaging_cost'])} · ${((p['confirmed'] as num)==1)?'Cost confirmed':'Cost not confirmed'}'),isThreeLine:true,trailing:IconButton(icon:const Icon(Icons.edit),onPressed:()=>_edit(context,p))))) ]);
  Future<void> _edit(BuildContext context,Map<String,Object?> p) async {final a=TextEditingController(text:'${p['purchase_cost']}'),b=TextEditingController(text:'${p['packaging_cost']}'),c=TextEditingController(text:'${p['other_unit_cost']}');final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Product cost details'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[Text('${p['product_name']}'),Text('SKU: ${p['seller_sku']}'),_field(a,'Wholesale purchase price'),_field(b,'Packaging cost per unit'),_field(c,'Other cost per unit')])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Save'))]));if(ok==true){await AppDatabase.instance.saveProductCost(storeId:storeId,sku:'${p['seller_sku']}',name:'${p['product_name']}',purchase:double.tryParse(a.text)??0,packaging:double.tryParse(b.text)??0,other:double.tryParse(c.text)??0);await onSaved();}a.dispose();b.dispose();c.dispose();}
}
Widget _field(TextEditingController c,String label)=>TextField(controller:c,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:InputDecoration(labelText:'$label (Rs.)'));

class OrderScreen extends StatelessWidget {final List<Map<String,Object?>> rows;final int storeId;final Future<void> Function() onChanged;const OrderScreen({super.key,required this.rows,required this.storeId,required this.onChanged});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('Order-level profit', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const Text('Confirm actual quantity and product cost before a line is marked profit-ready. Order-level fees are allocated by product revenue share.'),
      const SizedBox(height: 10),
      if (rows.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('Import statements to see order lines.'))),
      ...rows.map((r) {
        final ready = (r['profit_ready'] as num) == 1;
        final net = (r['line_settlement'] as num).toDouble() + ((r['allocated_order_fees'] as num?)?.toDouble() ?? 0);
        return Card(child: ListTile(
          isThreeLine: true,
          title: Text('${r['product_name']}', maxLines: 2, overflow: TextOverflow.ellipsis),
          subtitle: Text('Order ${r['order_number']} · Qty ${r['quantity']} · ${r['quantity_confirmed'] == 1 ? 'Quantity confirmed' : 'Quantity needed'}\nNet settlement ${money(net)}'),
          trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(ready ? money(r['actual_profit']) : 'Pending', style: TextStyle(fontWeight: FontWeight.bold, color: ready ? Colors.green : Colors.orange)),
            Text(ready ? 'Actual*' : 'Confirm data', style: const TextStyle(fontSize: 10)),
          ]),
          onTap: () => _edit(context, r),
        ));
      }),
    ],
  );

  Future<void> _edit(BuildContext context,Map<String,Object?> r) async {final qty=TextEditingController(text:'${r['quantity']??''}');final ret=TextEditingController(text:'0');final retCost=TextEditingController(text:'0');final notes=TextEditingController();bool restock=false;final action=await showDialog<String>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,set)=>AlertDialog(title:const Text('Order line details'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${r['product_name']}'),Text('Order: ${r['order_number']}'),Text('Order line: ${r['order_line_id']}'),_field(qty,'Confirmed sold quantity'),const Divider(),const Text('Record a return (optional)'),_field(ret,'Returned quantity'),_field(retCost,'Return handling/loss expense'),CheckboxListTile(value:restock,onChanged:(v)=>set(()=>restock=v??false),title:const Text('Returned units are restocked'),contentPadding:EdgeInsets.zero),TextField(controller:notes,decoration:const InputDecoration(labelText:'Return notes'))])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,'cancel'),child:const Text('Cancel')),TextButton(onPressed:()=>Navigator.pop(ctx,'return'),child:const Text('Save return')),FilledButton(onPressed:()=>Navigator.pop(ctx,'quantity'),child:const Text('Save quantity'))])));if(action=='quantity'){final v=double.tryParse(qty.text);if(v==null||v<0){_snack(context,'Enter a valid quantity.');}else{await AppDatabase.instance.saveOrderQuantity(storeId:storeId,orderNumber:'${r['order_number']}',orderLineId:'${r['order_line_id']}',sku:'${r['seller_sku']}',quantity:v);await onChanged();}}if(action=='return'){final v=double.tryParse(ret.text)??0;final e=double.tryParse(retCost.text)??0;if(v<=0){_snack(context,'Enter a returned quantity greater than zero.');}else{try{await AppDatabase.instance.addReturn(storeId:storeId,orderNumber:'${r['order_number']}',orderLineId:'${r['order_line_id']}',sku:'${r['seller_sku']}',quantity:v,restockable:restock,expense:e,notes:notes.text);await onChanged();}catch(err){_snack(context,err.toString().replaceFirst('Bad state: ',''));}}}qty.dispose();ret.dispose();retCost.dispose();notes.dispose();}
}
void _snack(BuildContext c,String s)=>ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text(s)));

class ExpenseScreen extends StatelessWidget {final List<Map<String,Object?>> rows;final int storeId;final Future<void> Function() onChanged;const ExpenseScreen({super.key,required this.rows,required this.storeId,required this.onChanged});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Business expenses',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),FilledButton.icon(onPressed:()=>_add(context),icon:const Icon(Icons.add),label:const Text('Add'))]),const Text('Record advertising, transport, packaging purchases not included in unit cost, and other overheads. Avoid entering the same expense twice.'),const SizedBox(height:10),...rows.map((r)=>Card(child:ListTile(title:Text('${r['category']}'),subtitle:Text('${r['expense_date']} · ${r['description']??''}'),trailing:Text(money(r['amount']),style:const TextStyle(fontWeight:FontWeight.bold))))) ]);
  Future<void> _add(BuildContext context) async {final amount=TextEditingController(),desc=TextEditingController();String category='Other';final ok=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,set)=>AlertDialog(title:const Text('Add business expense'),content:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButtonFormField<String>(value:category,items:['Advertising','Transport','Packaging','Storage','Utilities','Other'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>set(()=>category=v??'Other'),decoration:const InputDecoration(labelText:'Category')),_field(amount,'Amount'),TextField(controller:desc,decoration:const InputDecoration(labelText:'Description'))]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Save'))])));if(ok==true){final v=double.tryParse(amount.text);if(v==null||v<=0){_snack(context,'Enter a valid expense amount.');}else{await AppDatabase.instance.addExpense(storeId:storeId,date:DateFormat('yyyy-MM-dd').format(DateTime.now()),category:category,description:desc.text,amount:v);await onChanged();}}amount.dispose();desc.dispose();}
}

class ReportScreen extends StatelessWidget {final List<Map<String,Object?>> fees;final Map<String,Object?> summary;final int storeId;const ReportScreen({super.key,required this.fees,required this.summary,required this.storeId});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Financial reports', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        IconButton(tooltip: 'Export report CSV', onPressed: () => _export(context), icon: const Icon(Icons.download)),
      ]),
      Card(child: Column(children: [
        _reportRow('Product revenue', summary['product_sales']),
        _reportRow('Net Daraz settlement', summary['settlement']),
        _reportRow('Recorded business expenses', summary['expenses']),
        _reportRow('Unallocated adjustments (excluded from product profit)', summary['unallocated_amount']),
        _reportRow('VAT amount shown in statement (reference)', summary['vat_total']),
        _reportRow('WHT amount shown in statement (reference)', summary['wht_total']),
      ])),
      const SizedBox(height: 12),
      const Text('Daraz fee and adjustment breakdown', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
      ...fees.map((f) => Card(child: ListTile(
        title: Text('${f['fee_name']}'),
        trailing: Text(money(f['total']), style: const TextStyle(fontWeight: FontWeight.bold)),
      ))),
      const SizedBox(height: 14),
      const Text('Monthly summary', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
      FutureBuilder<List<Map<String, Object?>>>(
        future: AppDatabase.instance.monthlyReports(storeId: storeId),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Padding(padding: EdgeInsets.all(16), child: CircularProgressIndicator());
          final periods = snapshot.data!;
          if (periods.isEmpty) return const Padding(padding: EdgeInsets.all(12), child: Text('No monthly data yet.'));
          return Column(children: periods.map((m) => Card(child: ListTile(
            title: Text('${m['month']}'),
            subtitle: Text('Sales ${money(m['product_sales'])} · Expenses ${money(m['expenses'])} · Confirmed lines ${m['confirmed_lines']} · Pending ${m['pending_lines']}'),
            trailing: Column(mainAxisAlignment: MainAxisAlignment.center,crossAxisAlignment: CrossAxisAlignment.end,children:[Text(money(m['settlement']),style:const TextStyle(fontWeight:FontWeight.bold)),Text('Profit ${money(m['monthly_profit'])}',style:const TextStyle(fontSize:11))]),
          ))).toList());
        },
      ),
      const Padding(padding: EdgeInsets.all(8), child: Text('Profit is only final after sold quantities and product costs are confirmed, and returns are reconciled. Monthly settlement is not the same as monthly profit.', style: TextStyle(color: Colors.blueGrey, fontSize: 12))),
    ],
  );

  Future<void> _export(BuildContext context) async {
    try {
      final db=AppDatabase.instance; final orders=await db.orderLines(storeId:storeId); final monthly=await db.monthlyReports(storeId:storeId);
      final b=StringBuffer('Report Type,Reference,Product,SKU,Quantity,Net Settlement,Actual Profit,Status\n');
      for (final o in orders) {
        final ready = (o['profit_ready'] as num) == 1;
        final net = (o['line_settlement'] as num).toDouble() + ((o['allocated_order_fees'] as num?)?.toDouble() ?? 0);
        final orderNo = _csv(o['order_number']);
        final product = _csv(o['product_name']);
        final sku = _csv(o['seller_sku']);
        final quantity = o['quantity'];
        final profitValue = ready ? o['actual_profit'] : '';
        final status = ready ? 'Confirmed' : 'Needs confirmation';
        b.writeln('Order,$orderNo,$product,$sku,$quantity,$net,$profitValue,$status');
      }
      for (final m in monthly) {
        final monthName = _csv(m['month']);
        b.writeln('Month,$monthName,, ,${m['transaction_count']},${m['settlement']},${m['monthly_profit']},Sales ${m['product_sales']} Expenses ${m['expenses']} Pending lines ${m['pending_lines']}');
      }
      final stamp=DateFormat('yyyyMMdd').format(DateTime.now());
      final path=await FilePicker.platform.saveFile(fileName:'sellerprofit_report_$stamp.csv',bytes:Uint8List.fromList([0xEF,0xBB,0xBF,...utf8.encode(b.toString())]));
      if(path!=null&&context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('CSV report exported.')));
    }catch(e){if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Export failed: $e')));}
  }
  String _csv(Object? value) { final escaped = (value ?? '').toString().replaceAll('"', '""'); return '"$escaped"'; }
  Widget _reportRow(String label,Object? value)=>ListTile(title:Text(label),trailing:Text(money(value),style:const TextStyle(fontWeight:FontWeight.bold)));
}

class StatementScreen extends StatelessWidget {final List<Map<String,Object?>> statements;const StatementScreen({super.key,required this.statements});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Statement history',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:10),if(statements.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('Imported Daraz statements will appear here.'))),...statements.map((s)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.description_outlined)),title:Text('${s['statement_number']}'),subtitle:Text('${s['statement_period']} · ${s['transaction_count']} transactions'),trailing:Text(money(s['net_settlement']),style:const TextStyle(fontWeight:FontWeight.bold))))) ]);
}
