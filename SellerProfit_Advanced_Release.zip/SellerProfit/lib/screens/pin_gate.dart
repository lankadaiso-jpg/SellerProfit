import 'package:flutter/material.dart';
import '../services/pin_lock_service.dart';

class PinGate extends StatefulWidget {
  final Widget Function(BuildContext context, VoidCallback lockNow, Future<void> Function() changePin) builder;
  const PinGate({super.key, required this.builder});
  @override State<PinGate> createState() => _PinGateState();
}

class _PinGateState extends State<PinGate> with WidgetsBindingObserver {
  bool _loading = true;
  bool _configured = false;
  bool _unlocked = false;
  String? _error;
  final _pin = TextEditingController();
  final _confirm = TextEditingController();
  DateTime? _backgroundAt;

  @override void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  Future<void> _load() async {
    final configured = await PinLockService.instance.isPinConfigured();
    if (!mounted) return;
    setState(() { _configured = configured; _loading = false; _unlocked = false; });
  }

  @override void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _backgroundAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final leftAt = _backgroundAt;
      _backgroundAt = null;
      // A short grace period prevents Android's document picker from interrupting Excel imports.
      if (_unlocked && leftAt != null && DateTime.now().difference(leftAt) >= const Duration(seconds: 30) && mounted) {
        setState(() { _unlocked = false; _pin.clear(); });
      }
    } else if (state == AppLifecycleState.detached && _unlocked && mounted) {
      setState(() { _unlocked = false; _pin.clear(); });
    }
  }

  @override void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pin.dispose(); _confirm.dispose();
    super.dispose();
  }

  void _lockNow() { if (mounted) setState(() { _unlocked = false; _pin.clear(); _error = null; }); }

  Future<void> _submit() async {
    final value = _pin.text.trim();
    if (!RegExp(r'^\d{6}$').hasMatch(value)) { setState(() => _error = 'Enter exactly 6 digits.'); return; }
    if (!_configured) {
      if (_confirm.text.trim() != value) { setState(() => _error = 'PINs do not match. Please try again.'); return; }
      await PinLockService.instance.setPin(value);
      if (mounted) setState(() { _configured = true; _unlocked = true; _error = null; _pin.clear(); _confirm.clear(); });
      return;
    }
    final valid = await PinLockService.instance.verifyPin(value);
    if (!mounted) return;
    if (valid) setState(() { _unlocked = true; _error = null; _pin.clear(); })
    else setState(() => _error = 'Incorrect PIN. Please try again.');
  }

  Future<void> _changePin() async {
    final current = TextEditingController();
    final next = TextEditingController();
    final confirm = TextEditingController();
    String? error;
    await showDialog<void>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, refresh) => AlertDialog(
      title: const Text('Change app PIN'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: current, obscureText: true, keyboardType: TextInputType.number, maxLength: 6, decoration: const InputDecoration(labelText: 'Current 6-digit PIN')),
        TextField(controller: next, obscureText: true, keyboardType: TextInputType.number, maxLength: 6, decoration: const InputDecoration(labelText: 'New 6-digit PIN')),
        TextField(controller: confirm, obscureText: true, keyboardType: TextInputType.number, maxLength: 6, decoration: const InputDecoration(labelText: 'Confirm new PIN')),
        if (error != null) Align(alignment: Alignment.centerLeft, child: Text(error!, style: const TextStyle(color: Colors.red))),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')), FilledButton(onPressed: () async {
        if (!await PinLockService.instance.verifyPin(current.text.trim())) { refresh(() => error = 'Current PIN is incorrect.'); return; }
        if (!RegExp(r'^\d{6}$').hasMatch(next.text.trim())) { refresh(() => error = 'New PIN must contain exactly 6 digits.'); return; }
        if (next.text.trim() != confirm.text.trim()) { refresh(() => error = 'New PINs do not match.'); return; }
        await PinLockService.instance.setPin(next.text.trim());
        if (ctx.mounted) Navigator.pop(ctx);
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PIN changed successfully.')));
      }, child: const Text('Save PIN'))],
    )));
    current.dispose(); next.dispose(); confirm.dispose();
  }

  @override Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (_unlocked) return widget.builder(context, _lockNow, _changePin);
    return Scaffold(
      body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(28), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 380), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 76, height: 76, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(24)), child: Icon(Icons.lock_outline, size: 38, color: Theme.of(context).colorScheme.primary)),
        const SizedBox(height: 22), Text(_configured ? 'Welcome back' : 'Protect SellerProfit', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8), Text(_configured ? 'Enter your 6-digit PIN to open your business dashboard.' : 'Create a 6-digit PIN. You will need it whenever you open or return to the app.', textAlign: TextAlign.center, style: const TextStyle(color: Colors.blueGrey)),
        const SizedBox(height: 24), TextField(controller: _pin, obscureText: true, keyboardType: TextInputType.number, maxLength: 6, textAlign: TextAlign.center, style: const TextStyle(fontSize: 24, letterSpacing: 12), decoration: const InputDecoration(labelText: '6-digit PIN', border: OutlineInputBorder(), counterText: '')),
        if (!_configured) ...[const SizedBox(height: 12), TextField(controller: _confirm, obscureText: true, keyboardType: TextInputType.number, maxLength: 6, textAlign: TextAlign.center, style: const TextStyle(fontSize: 24, letterSpacing: 12), decoration: const InputDecoration(labelText: 'Confirm PIN', border: OutlineInputBorder(), counterText: ''))],
        if (_error != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_error!, style: const TextStyle(color: Colors.red))),
        const SizedBox(height: 18), SizedBox(width: double.infinity, child: FilledButton(onPressed: _submit, child: Text(_configured ? 'Unlock SellerProfit' : 'Create PIN'))),
        const SizedBox(height: 12), const Text('Your PIN is stored securely on this device.', style: TextStyle(fontSize: 12, color: Colors.blueGrey)),
      ]))))),
    );
  }
}
