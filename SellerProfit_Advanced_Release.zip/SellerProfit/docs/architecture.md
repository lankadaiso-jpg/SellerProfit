# SellerProfit technical architecture

## Runtime

- Flutter Android client (Dart 3.4+).
- Local SQLite via `sqflite` for offline-first operation.
- `excel` package for XLSX decoding; `file_picker` for file selection and export.
- `flutter_secure_storage` and salted SHA-256 PIN verification for app lock.
- `intl` for LKR formatting and month grouping.
- No remote API, cloud database or AI provider is required for this private local build.

## Data model

### stores
`id`, `name`, `marketplace`, `created_at`.

### statements
`id`, `store_id`, `statement_number`, `statement_period`, `imported_at`, `transaction_count`, `net_settlement`; unique `(store_id, statement_number)`.

### transactions
`id`, `store_id`, statement/date fields, `fee_name`, signed `amount`, `vat_amount`, `wht_amount`, WHT inclusion flag, release/comment/order fields, order IDs, seller SKU, Lazada SKU, product name, short code and status.

### products
`id`, `store_id`, `seller_sku`, `product_name`, purchase cost, packaging cost, other unit cost and cost confirmation flag; unique `(store_id, seller_sku)`.

### order_line_quantities
Confirmed sold quantity keyed by store, order line and SKU.

### returns
Returned quantity, restockable flag, return expense, note and date, keyed to store/order/order-line/SKU.

### expenses
Business overhead date, category, description and amount by store.

### import_audit
Imported filename, statement number, timestamp and row count.

## Processing flow

`XLSX picker -> DarazExcelParser -> ParsedStatement -> duplicate check -> SQLite transaction -> order-line aggregation -> fee allocation -> profit calculation -> dashboard/reports`

## Security

- PIN hash and random salt are stored using Android secure storage.
- The SQLite database remains local to the app sandbox.
- Backup files are portable JSON and should be stored in a private location.
- Restoring a backup replaces current app data.

## Database versions

- v1: initial single-store import and product cost tables.
- v2: store profiles, store-scoped uniqueness, quantity confirmations, returns and import audit.
- v3: WHT, release date, comment, order creation date, Lazada SKU and short code transaction fields.
