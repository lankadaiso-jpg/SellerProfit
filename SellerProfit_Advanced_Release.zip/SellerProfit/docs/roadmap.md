# Delivery status and remaining phases

## Delivered in this source release

- Phase 1 core: PIN-protected Android Flutter source, XLSX import, local storage, product costs, statement history and dashboard.
- Advanced profit milestone: confirmed order quantities, order-line profit, proportional allocation of order-level Daraz amounts, return records, operating expenses, monthly summaries, CSV reports, JSON backup/restore and multiple store profiles.

## Phase 2 — inventory operations (next release)

- Supplier directory and supplier price history.
- Purchase batches and receiving records.
- Stock-on-hand and stock movements.
- Restock alerts and low-stock dashboard.
- Purchase invoice/receipt attachment.

## Phase 3 — smart seller tools (next release)

- Selling-price calculator with editable marketplace fee assumptions and target margin.
- Product performance ranking and trend analysis.
- Rule-based restock and price recommendations.
- Optional AI assistant. A secure backend and user-provided AI service credentials would be required; secret API keys must not be embedded in the Android APK.

The Phase 2 and Phase 3 items above are planned, not represented as already implemented in this archive. The current build completes the previously recommended advanced profit-engine milestone, not the entire future roadmap.
