# SellerProfit accounting rules

## Source transaction handling

- Each imported Daraz transaction row is stored once, unchanged in signed amount.
- Statement uniqueness is `(store_id, statement_number)`.
- `Amount(Include Tax)` is the settlement amount source. VAT and WHT are stored as separate informational columns; do not double count them.
- A new or unknown fee name is retained automatically and appears in the fee breakdown.

## Order-line calculation

For a given store, order number, order-line ID and SKU:

1. Sum all transaction amounts linked directly to that order line across all imported statements.
2. Find transactions with an order number but no order-line ID. Allocate those amounts among the order's product lines by each line's share of positive `Product Price Paid by Buyer` revenue.
3. If no positive product revenue exists for an order, do not allocate its unlinked transactions. Show them in unallocated adjustments.
4. Subtract COGS using the manually confirmed sold quantity and saved unit cost.
5. For returned stock marked restockable, reverse COGS for those units. Non-restockable returns do not reverse COGS.
6. Subtract recorded return handling/loss expenses.

`order_line_profit = line_settlement + allocated_order_fees - COGS - return_expenses`

`dashboard_confirmed_profit = sum(confirmed_order_line_profit) - recorded_business_expenses`

## Confirmation rules

A line is profit-ready only when:
- The seller has confirmed the sold quantity for that order line; and
- The seller has confirmed purchase, packaging and other unit costs for its SKU.

The app does not assume one item per order line. The supplied Daraz workbook does not provide an explicit quantity column.

## Returns

Daraz statement refund/credit transactions are included in the transaction ledger. A manual return record only records the physical quantity returned, whether it is saleable/restocked, and additional return expenses. Do not enter the Daraz refund amount again as an expense because that would double count it.

## Known limitations

- The order-level allocation method is a transparent proportional allocation and may not match Daraz's internal fee allocation in every case.
- Transactions with no order line and no allocatable order revenue remain unallocated and are excluded from product-level profit.
- Monthly report settlement is grouped by transaction date. It is not a monthly accounting P&L and can differ from statement-period settlement.
- No official Daraz API connection is included. Excel statements remain the source of truth.
- No tax filing or statutory accounting advice is provided.

## Example statement validation

The supplied sample statement contains 51 transaction rows. Summing its signed `Amount(Include Tax)` column gives **LKR 5,483.92**. Product-price rows sum to **LKR 8,377.00**, and buyer-paid shipping rows sum to **LKR 950.00**. These are statement facts, not profit. SellerProfit should reproduce the settlement total when this workbook is imported.
