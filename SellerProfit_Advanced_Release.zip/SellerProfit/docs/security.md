# SellerProfit PIN protection

- On first launch, the app requires creation and confirmation of a 6-digit PIN.
- The PIN is salted and SHA-256 hashed; the salt and hash are stored using Android secure storage through `flutter_secure_storage`.
- The app locks after it has been in the background for 30 seconds. The grace period helps prevent the Android file picker from interrupting an Excel import.
- The app menu provides **Change PIN** and **Lock now**.
- The PIN is device-local and is not synced to a cloud account.

## Important security notes

The PIN is an app-level access barrier, not a replacement for Android device encryption or a complete security review. The SQLite database is stored in the app's private sandbox but is not separately SQLCipher-encrypted in this release. JSON backup files are readable data; store them in a private, protected location and do not share them. A user who clears app data or uninstalls the app may lose local data. Encrypted database/backup support should be added before distributing the app to other users.
